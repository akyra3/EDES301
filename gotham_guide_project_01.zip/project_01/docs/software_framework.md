# Software Framework

## Software Block Diagram

```text
User
  ↓
UserMenu
  ↓
ButtonInput
  ↓
MainController
  ↓
RecommendationEngine
  ↓
ComicDatabase
  ↓
OutputDisplay
  ↓
Terminal Output
```

## Software Flow

```text
Power on PocketBeagle
  ↓
Start Python program
  ↓
Load comics.json
  ↓
Show user menu
  ↓
User selects rogue and/or mood
  ↓
Wait for button press
  ↓
Generate recommendation
  ↓
Display comic title, creators, and reason
  ↓
Ask user whether to run again
```

## Class Descriptions

### MainController

Controls the main program loop. It connects the menu, button input, database, recommendation engine, and output display.

### ButtonInput

Handles the push button. If the program is running on the PocketBeagle with Adafruit_BBIO installed, it uses GPIO. Otherwise, it falls back to a simulated button press using Enter.

### UserMenu

Handles terminal-based user choices for rogue and mood selection.

### ComicDatabase

Loads the local comic database from `comics.json`.

### RecommendationEngine

Filters comics based on rogue and mood tags. If both are selected, it prioritizes matches containing both tags. If only one is selected, it returns comics matching that tag.

### OutputDisplay

Formats recommendation results for the user.
